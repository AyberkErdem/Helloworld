package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import java.util.Random;

import java.nio.charset.Charset;

public class MainActivity extends AppCompatActivity {
    TextView tv,tv1;
    Button b,b1;
    CharSequence str;
    Toast t;
    Random rn;
    int s1;
    int s2,pn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rn=new Random();
         b=(Button)findViewById(R.id.btn);
        b1=(Button)findViewById(R.id.btn2);
        s1=rn.nextInt(20);
        s2=rn.nextInt(20);
        pn=0;

        tv=(TextView)findViewById(R.id.toptxt);
        tv1=(TextView)findViewById(R.id.puantxt);
        tv.setText("Uygulama\nHangi sayı büyükse ona bas");
        String s=String.valueOf(pn);
        tv1.setText("Puan:"+s.toString());
        b.setText(String.valueOf(s1));
        b1.setText(String.valueOf(s2));
        while(s1==s2)
        {
            s1=rn.nextInt(20);
            s2=rn.nextInt(20);
        }
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(s1>=s2)
                {
                    pn++;
                    tv1.setText("Puan:"+String.valueOf(pn));
                }
                else if(s1<s2)
                {
                    pn--;
                    tv1.setText("Puan:"+String.valueOf(pn));
                }
                else if(s1==s2)
                {

                    b.setText(String.valueOf(s1));
                    b1.setText(String.valueOf(s2));
                }

                s1=0;
                s2=0;
                while(s1==s2)
                {
                    s1=rn.nextInt(20);
                    s2=rn.nextInt(20);
                }
                b.setText(String.valueOf(s1));
                b1.setText(String.valueOf(s2));
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(s2>s1)
                {
                    pn++;
                    tv1.setText("Puan:"+String.valueOf(pn));
                }
                else if(s2<s1)
                {
                    pn--;
                    tv1.setText("Puan:"+String.valueOf(pn));
                }
                else if(s1==s2)
                {

                    b.setText(String.valueOf(s1));
                    b1.setText(String.valueOf(s2));
                }
                s1=0;
                s2=0;
                while(s1==s2)
                {
                    s1=rn.nextInt(20);
                    s2=rn.nextInt(20);
                }

                b.setText(String.valueOf(s1));
                b1.setText(String.valueOf(s2));

            }
        });
    }

}
