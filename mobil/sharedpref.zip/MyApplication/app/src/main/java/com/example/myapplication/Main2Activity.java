package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends AppCompatActivity {
Button b1,b2,b3;
View v1;
String tag="ayberk";
@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ;
        setContentView(R.layout.activity_main2);
        v1=(View)findViewById(R.id.view23);
        b1=(Button)findViewById(R.id.redbtn);
        b2=(Button)findViewById(R.id.bluebtn);
        b3=(Button)findViewById(R.id.greenbtn);
        SharedPreferences preferences=getSharedPreferences("Settings",MODE_PRIVATE);
        String s=String.valueOf(preferences.getString("key1",""));
        Log.d(tag,s);
        int a=Integer.parseInt(s);
        if(a==1)
        {
            v1.setBackgroundColor(Color.RED);
            Log.d(tag,"Yapttım");
        }
        else if(a==2)
        {
            v1.setBackgroundColor(Color.BLUE);
            Log.d(tag,"Yaptım");
        }
        else if(a==3)
        {
            v1.setBackgroundColor(Color.GREEN);
            Log.d(tag,"yasf");
        }
        else if(s=="")
        {
            v1.setBackgroundColor(Color.WHITE);
            Log.d(tag,"Yaptımıkamsd");
        }
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v1.setBackgroundColor(Color.RED);
                SharedPreferences preferences=getSharedPreferences("Settings",MODE_PRIVATE);
                SharedPreferences.Editor editor=preferences.edit();
                editor.putString("key1","1");
                editor.apply();
                finish();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v1.setBackgroundColor(Color.BLUE);
                SharedPreferences preferences=getSharedPreferences("Settings",MODE_PRIVATE);
                SharedPreferences.Editor editor=preferences.edit();
                editor.putString("key1","2");
                editor.apply();
                finish();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v1.setBackgroundColor(Color.GREEN);
                SharedPreferences preferences=getSharedPreferences("Settings",MODE_PRIVATE);
                SharedPreferences.Editor editor=preferences.edit();
                editor.putString("key1","3");
                editor.apply();
                finish();
            }
        });

    }
}
