package com.example.mobillab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
RadioButton rb1,rb2,rb3,rb4,rb5,rb6;
ImageView ım;
    String result="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ım=(ImageView)findViewById(R.id.ImageV);
         rb1=(RadioButton)findViewById(R.id.İlkBtn);
        rb2=(RadioButton)findViewById(R.id.SonBtn);
        rb3=(RadioButton)findViewById(R.id.KışBtn);
        rb4=(RadioButton)findViewById(R.id.YazBtn);
        rb1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                ım.setVisibility(View.VISIBLE);
                if(rb1.isChecked()==true)
                {
                    ım.setImageResource(R.drawable.ilkbahar);
                }
               else if(rb2.isChecked()==true)
                {
                    ım.setImageResource(R.drawable.sonbahar);
                }
               else if(rb3.isChecked()==true)
                {
                    ım.setImageResource(R.drawable.kis);
                }
                else if(rb4.isChecked()==true)
                {
                    ım.setImageResource(R.drawable.yaz);
                }
            }
        });

    }


    public void Click(View view) {

        ım.setVisibility(View.VISIBLE);
        if(rb1.isChecked()==true)
        {
            ım.setImageResource(R.drawable.ilkbahar);
        }
        else if(rb2.isChecked()==true)
        {
            ım.setImageResource(R.drawable.sonbahar);
        }
        else if(rb3.isChecked()==true)
        {
            ım.setImageResource(R.drawable.kis);
        }
        else if(rb4.isChecked()==true)
        {
            ım.setImageResource(R.drawable.yaz);
        }
    }
}
