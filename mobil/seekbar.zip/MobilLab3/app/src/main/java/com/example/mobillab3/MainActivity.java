package com.example.mobillab3;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
RadioButton rb1,rb2,rb3,rb4,rb5,rb6;
Spinner s1;
ImageView ım;
TextView t1,t2,t3;
SeekBar sb1,sb2,sb3;
View v1;
int red=0,green=0,blue=0;
    String result="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       sb1=(SeekBar)findViewById(R.id.seekBar5);
       sb2=(SeekBar)findViewById(R.id.seekBar6);
       sb3=(SeekBar)findViewById(R.id.seekBar7);
       v1=(View)findViewById(R.id.view);
        red=sb2.getProgress();
        green=sb1.getProgress();
        blue=sb3.getProgress();
        t1=(TextView)findViewById(R.id.red);
        t2=(TextView)findViewById(R.id.Green);
        t3=(TextView)findViewById(R.id.Blue);
        sb1.setMax(255);
        sb2.setMax(255);
        sb3.setMax(255);
        v1.setBackgroundColor(Color.rgb(red,green,blue));
       sb1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
           @Override
           public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
               green=sb1.getProgress();
               t2.setText("Green"+String.valueOf(green));
               v1.setBackgroundColor(Color.rgb(red,green,blue));
           }

           @Override
           public void onStartTrackingTouch(SeekBar seekBar) {

           }

           @Override
           public void onStopTrackingTouch(SeekBar seekBar) {

           }
       });

        sb2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                red=sb2.getProgress();
                t1.setText("Red"+String.valueOf(red));
                v1.setBackgroundColor(Color.rgb(red,green,blue));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sb3.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                blue=sb3.getProgress();
                t3.setText("Blue"+String.valueOf(blue));
                v1.setBackgroundColor(Color.rgb(red,green,blue));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

/*
    public void Click(View view) {
    barbaracalculator++;
        ım.setVisibility(View.VISIBLE);
        if(barbaracalculator>=6)
        {

           ım.setImageResource(R.drawable.adsiz);

            Toast.makeText(getApplicationContext(),"Manken olan",Toast.LENGTH_SHORT).show();

            ım.setImageResource(R.drawable.barbara);
           barbaracalculator=0;
        }

       else if(rb1.isChecked()==true)
        {
            ım.setImageResource(R.drawable.ilkbahar);
        }
        else if(rb2.isChecked()==true)
        {
            ım.setImageResource(R.drawable.sonbahar);
        }
        else if(rb3.isChecked()==true)
        {
            ım.setImageResource(R.drawable.kis);
        }
        else if(rb4.isChecked()==true)
        {
            ım.setImageResource(R.drawable.yaz);
        }
    }

 */
}
