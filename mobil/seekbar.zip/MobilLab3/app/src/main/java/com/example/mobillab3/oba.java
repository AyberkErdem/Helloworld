/*
package com.example.mobillab3;

public class obapublic class MainActivity extends Activity {

    //Değişkenleri tanımlıyoruz.
    View background;

    SeekBar redSeekBar;
    SeekBar greenSeekBar;
    SeekBar blueSeekBar;

    int redValue;
    int greenValue;
    int blueValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        background = findViewById(R.id.background);

        redSeekBar = (SeekBar) findViewById(R.id.seekBarRed);
        greenSeekBar = (SeekBar) findViewById(R.id.seekBarGreen);
        blueSeekBar = (SeekBar) findViewById(R.id.seekBarBlue);

        redValue  = redSeekBar.getProgress();
        greenValue  = greenSeekBar.getProgress();
        blueValue  = blueSeekBar.getProgress();

        //SeekBar'ların max değerlerini 255 olarak set ediyoruz.
        redSeekBar.setMax(255);
        greenSeekBar.setMax(255);
        blueSeekBar.setMax(255);

        //Arkaplanın başlangıç rengini set ediyoruz.
        background.setBackgroundColor(Color.rgb(redValue, greenValue, blueValue));

        redSeekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                //Arkaplanı yeni değere göre set ediyoruz.
                redValue = progress;
                background.setBackgroundColor(Color.rgb(redValue, greenValue, blueValue));
            }
        });

        greenSeekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                //Arkaplanı yeni değere göre set ediyoruz.
                greenValue = progress;
                background.setBackgroundColor(Color.rgb(redValue, greenValue, blueValue));
            }
        });

        blueSeekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                //Arkaplanı yeni değere göre set ediyoruz.
                blueValue = progress;
                background.setBackgroundColor(Color.rgb(redValue, greenValue, blueValue));
            }
        });

    }

} {
}
*/