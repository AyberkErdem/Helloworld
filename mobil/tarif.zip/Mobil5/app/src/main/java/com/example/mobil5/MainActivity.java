package com.example.mobil5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
String tag;
Spinner s1;
ArrayList categories;
ImageView v1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        s1=(Spinner)findViewById(R.id.spinner);
        v1=(ImageView)findViewById(R.id.imageView2);
        categories=new ArrayList<String>();
        categories.add("aşure");
        categories.add("manti");
        categories.add("mercimek");
        categories.add("salata");
        ArrayAdapter<String>dataAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, categories);
       s1.setAdapter(dataAdapter);
       s1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
           @Override
           public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
           if(position==0)
           {
               v1.setImageResource(R.drawable.asure);
           }
              else if(position==1)
               {
                   v1.setImageResource(R.drawable.manti);
               }
              else if(position==2)
               {
                   v1.setImageResource(R.drawable.merc);
               }
               else if(position==3)
               {
                   v1.setImageResource(R.drawable.salad);
               }

           }

           @Override
           public void onNothingSelected(AdapterView<?> parent) {

           }
       });
    }

    public void Yap(View view)
    {
        Intent intent=new Intent(this,Main2Activity.class);

        if(s1.getSelectedItem()=="aşure")//aşure
        {
            intent.putExtra("message","0");
        }
        else if(s1.getSelectedItem()=="manti")//manti
        {
            intent.putExtra("message","1");
        }
        else if(s1.getSelectedItem()=="mercimek")//mercimek
        {
            intent.putExtra("message","2");
        }
        else if(s1.getSelectedItem()=="salata")//salata
        {
            intent.putExtra("message","3");
        }
        startActivity(intent);
    }
}
