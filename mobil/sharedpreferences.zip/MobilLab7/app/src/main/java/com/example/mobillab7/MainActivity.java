package com.example.mobillab7;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText et1,et2;
    private static final int PERMISSION_REQUEST_CODE=1;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(MainActivity.this,
                            "Permission accepted", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(MainActivity.this,
                            "Permission denied", Toast.LENGTH_LONG).show();
                }
                break;
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkPermission()) {
                Log.e("permission", "Permission already granted.");
            } else {
                requestPermission();
            }
        }
        SharedPreferences prefs = getPreferences(MODE_PRIVATE);

        String s = prefs.getString("name", "defaultValue");

        et1=findViewById(R.id.template);
        et2=findViewById(R.id.database);
        et2.setText(s);
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},
                PERMISSION_REQUEST_CODE);
    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }
    public void SendSMS(String num,String text) {

        if(checkPermission()) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(String.valueOf(num), null, text, null, null);
        }else {
            Toast.makeText(MainActivity.this, "Permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    public void send(View view)
    {
        String resul,resul1;
        String []at1,at2,at3;
        try
        {
            resul=String.valueOf(et1.getText());
            at1=resul.split("$");
            resul1=String.valueOf(et2.getText());
                at2=resul1.split("\\|");

            {
                for (int i = 0; i < at2.length; i++) {
                    at3=at2[i].split(";");
                    if(at3.length!=4)
                    {
                        Toast.makeText(this, "Satır hatası", Toast.LENGTH_SHORT).show();
                    }
                    else
                        {
                        resul = resul.replace("$NAME$", at3[0]);
                        resul = resul.replace("$SURNAME$", at3[1]);
                        resul = resul.replace("$PHONE$", at3[2]);
                        resul = resul.replace("$SUBJECT$", at3[3]);
                            SendSMS(String.valueOf(at3[2]), resul);
                    }
                }


            }

        }catch (Exception ex)
        {
            Toast.makeText(this, "Olmadı", Toast.LENGTH_SHORT).show();
        }

    }

    public void save(View view)
    {
        try{
        String resul1;
        int j;
        String[]at2;
        resul1=String.valueOf(et2.getText());
        at2=resul1.split("\\|");
        SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = prefs.edit();
        for(j=0;j<at2.length;j++)
        {
            prefsEditor.putString("name", at2[j]);
            prefsEditor.apply();
        }
        }
        catch (Exception ex)
        {
            Toast.makeText(this, "Cannot saved", Toast.LENGTH_SHORT).show();
        }

    }

}
