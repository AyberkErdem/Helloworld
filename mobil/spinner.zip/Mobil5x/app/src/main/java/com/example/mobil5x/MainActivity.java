package com.example.mobil5x;

import androidx.appcompat.app.AppCompatActivity;

import android.app.LauncherActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView L1;
    ArrayList mlist,klist,alist,sporyus;
    EditText et;
    String del;
    ArrayAdapter<String> dataAdapter,d2,d3,dataryus;
    String[]ah,ah2,ah3;
    Spinner s1;
    Button b1,b2,b3;
    int a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        L1=(ListView)findViewById(R.id.liste1);
        s1=(Spinner)findViewById(R.id.s1);
        b1=(Button)findViewById(R.id.ekle);
        b2=(Button)findViewById(R.id.sil);
        b3=(Button)findViewById(R.id.gün);
        sporyus=new ArrayList<String>();
        sporyus.add("Akdeniz");
        sporyus.add("Karadeniz");
        sporyus.add("Marmara");
        ah=getResources().getStringArray(R.array.Akdeniz);
        ah2=getResources().getStringArray(R.array.Karadeniz);
        ah3=getResources().getStringArray(R.array.Marmara);
        mlist=new ArrayList<String>();
        mlist.add("Bursa");
        mlist.add("Çanakkale");
        mlist.add("Balıkesir");
        alist=new ArrayList<String>();
        alist.add("Antalya");
        alist.add("Mersin");
        alist.add("Adana");
        klist=new ArrayList<String>();
        klist.add("Trabzon");
        klist.add("Bayburt");
        klist.add("Karabük");
        dataAdapter= new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, alist);
        d2= new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, klist);
        d3= new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, mlist);
        dataryus=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, sporyus);
        dataryus.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        L1.setAdapter(dataAdapter);
        s1.setAdapter(dataryus);
        et=(EditText)findViewById(R.id.editText);

    L1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        del=String.valueOf(position);
    }
    });
    s1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            a=position;
            if(position==0)
            {
                L1.setAdapter(dataAdapter);
                dataAdapter.notifyDataSetChanged();
            }
            else if(position==1)
            {
                L1.setAdapter(d2);
                dataAdapter.notifyDataSetChanged();
            }
            else if(position==2)
            {

                L1.setAdapter(d3);
                dataAdapter.notifyDataSetChanged();
            }
            else if(position==3)
            {
                ah=getResources().getStringArray(R.array.İçanadolu);
                dataAdapter.notifyDataSetChanged();
                L1.setAdapter(dataAdapter);
                dataAdapter.notifyDataSetChanged();
            }
           else if(position==4)
            {
                ah=getResources().getStringArray(R.array.DoğuAnadolu);
                dataAdapter.notifyDataSetChanged();
                L1.setAdapter(dataAdapter);
                dataAdapter.notifyDataSetChanged();
            }
            else if(position==5)
            {
                ah=getResources().getStringArray(R.array.GDA);
                dataAdapter.notifyDataSetChanged();
                L1.setAdapter(dataAdapter);
                dataAdapter.notifyDataSetChanged();
            }
            else if(position==6)
            {
                ah=getResources().getStringArray(R.array.Ege);
                dataAdapter.notifyDataSetChanged();
                L1.setAdapter(dataAdapter);
                dataAdapter.notifyDataSetChanged();
            }


        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    });
    }


    public void Yap(View view)
    {
        try {

            String c;
           // c = String.valueOf(et.getText());
            if (et.length()!=0)
            {
                if(a==0)//akdeniz
                {
                    String ek = String.valueOf(et.getText());
                    et.setText("");
                    alist.add(ek);
                    dataAdapter.notifyDataSetChanged();

                }
                else if(a==1)//kara
                {
                    String ek = String.valueOf(et.getText());
                    et.setText("");
                    klist.add(ek);
                    dataAdapter.notifyDataSetChanged();
                }
                else if(a==2)//maramara
                {
                    String ek = String.valueOf(et.getText());
                    et.setText("");
                    mlist.add(ek);
                    dataAdapter.notifyDataSetChanged();
                }
            }
            else
                {
                    Toast.makeText(this, "Boş isim", Toast.LENGTH_SHORT).show();
                }

        }
        catch (Exception ex)
        {

        }

    }
    boolean Tryparse(String s)
    {
        try
        {
            Integer.parseInt(s);
            return true;
        }
        catch (NumberFormatException ex)
        {
            return false;
        }

    }

    public void sil(View view)
    {
        try {
            String c;
            c = String.valueOf(et.getText());
            int k;
            if ( Tryparse(del) == true) {
                if (a == 0)//akdeniz
                {
                    String ek = String.valueOf(et.getText());
                    k=Integer.parseInt(del);
                    et.setText("");
                    alist.remove(k);
                    dataAdapter.notifyDataSetChanged();

                } else if (a == 1)//kara
                {
                    String ek = String.valueOf(et.getText());
                    k=Integer.parseInt(del);
                    et.setText("");
                    klist.remove(k);
                    dataAdapter.notifyDataSetChanged();
                } else if (a == 2)//maramara
                {
                    String ek = String.valueOf(et.getText());
                    k=Integer.parseInt(del);
                    et.setText("");
                    mlist.remove(k);
                    dataAdapter.notifyDataSetChanged();
                }
            }
            else
            {
                Toast.makeText(this, "Boş isim", Toast.LENGTH_SHORT).show();
            }

        }
        catch (Exception ex)
        {

        }
    }

    public void cık(View view)
    {
        try
        {
            int k;
        if(et.length()!=0 &&Tryparse(del)==true)
        {
            if (a == 0)//akdeniz
            {
                String ek = String.valueOf(et.getText());
                k=Integer.parseInt(del);
                et.setText("");
                alist.set(k,ek);
                dataAdapter.notifyDataSetChanged();

            } else if (a == 1)//kara
            {
                String ek = String.valueOf(et.getText());
                k=Integer.parseInt(del);
                et.setText("");
                klist.set(k,ek);
                dataAdapter.notifyDataSetChanged();
            } else if (a == 2)//maramara
            {
                String ek = String.valueOf(et.getText());
                k=Integer.parseInt(del);
                et.setText("");
                mlist.set(k,ek);
                dataAdapter.notifyDataSetChanged();
            }
        }
        }
        catch (Exception ex)
        {

        }
    }
}

    /*
        L1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Toast.makeText(MainActivity.this, deger, Toast.LENGTH_SHORT).show();
            }
        });

         */