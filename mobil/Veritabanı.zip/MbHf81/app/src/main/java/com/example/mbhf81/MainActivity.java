package com.example.mbhf81;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView lv;
    ArrayAdapter<String> adapter;
    ArrayList<HashMap<String, String>> kitap_liste;
    String kitap_adlari[];
    int kitap_idler[];

    @Override
    protected void onResume() {
        super.onResume();
        Database db = new Database(getApplicationContext()); // Db bağlantısı oluşturuyoruz. İlk seferde database oluşturulur.
        kitap_liste = db.kitaplar();//kitap listesini alıyoruz
        if(kitap_liste.size()==0){//kitap listesi boşsa
            Toast.makeText(getApplicationContext(), "Henüz Kitap Eklenmemiş.\nYukarıdaki + Butonundan Ekleyiniz", Toast.LENGTH_LONG).show();
        }else{
            kitap_adlari = new String[kitap_liste.size()]; // kitap adlarını tutucamız string arrayi olusturduk.
            kitap_idler = new int[kitap_liste.size()]; // kitap id lerini tutucamız string arrayi olusturduk.
            for(int i=0;i<kitap_liste.size();i++){
                kitap_adlari[i] = kitap_liste.get(i).get("kitap_adi");
                //kitap_liste.get(0) bize arraylist içindeki ilk hashmap arrayini döner. Yani tablomuzdaki ilk satır değerlerini
                //kitap_liste.get(0).get("kitap_adi") //bize arraylist içindeki ilk hashmap arrayin anahtarı kitap_adi olan value döner

                kitap_idler[i] = Integer.parseInt(kitap_liste.get(i).get("id"));
                //Yukarıdaki ile aynı tek farkı değerleri integer a çevirdik.
            }
            //Kitapları Listeliyoruz ve bu listeye listener atıyoruz
            lv = (ListView) findViewById(R.id.list_view);

            adapter = new ArrayAdapter<String>(this, R.layout.listitem, R.id.kitap_adi, kitap_adlari);
            lv.setAdapter(adapter);

            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                        long arg3) {
                    //Listedeki her hangibir yere tıklandıgında tıklanan satırın sırasını alıyoruz.
                    //Bu sıra id arraydeki sırayla aynı oldugundan tıklanan satırda bulunan kitapın id sini alıyor ve kitap detaya gönderiyoruz.
                    Intent intent = new Intent(getApplicationContext(), kitapdetay.class);
                    intent.putExtra("id", (int)kitap_idler[arg2]);
                    startActivity(intent);

                }
            });
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private void KitapEkle() {
        Intent i = new Intent(MainActivity.this, KitapEkle.class);
        startActivity(i);
    }

    public void Ekle(View view) {
        KitapEkle();
    }

    public void list(View view)
    {
        Intent i = new Intent(MainActivity.this, Listleme.class);
        startActivity(i);
    }
}