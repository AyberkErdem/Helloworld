package com.example.dvancedcalculation;

import android.view.View;
import android.widget.Toast;

public class yığın {

    String a;
    String sayı;
    String post="";
    public boolean ParseTry(String a)//TRY PARSE
    {
        try
        {
            Integer.parseInt(a);
            return true;
        }
        catch (NumberFormatException ex)
        {
            return false;
        }
    }
    public void pushop(String x)//PUSHİNG OPERATORS
    {
        a+=x;
    }
    public String popop()//POPİNG OPERATORS
    {
        if(a.length()!=0)
        {
            String temp;
            temp=a.substring(0,a.length()-1);
            a=a.substring(0,a.length()-1);
            return temp;
        }
        else
        {
            return "Nothing to pop";
        }
    }
    public void pushi(int x)//PUSHİNG İNTEGERS
    {
        if(sayı.length()==0)
            sayı=String.valueOf(x);
        else
            sayı+=","+String.valueOf(x);
    }
    public String emptypopop()//EMPTYİNG ALL OPERATORS
    {
        String pre="";
        String ress="";
        try {
            if (popop() == "(")
                return "No operator Found";
            else {
                while (popop() != "(")
                {

                    ress += popop();
                }
                if (popop() != "(" && a.length() != 0) {
                    ress += popop();
                }

            }
            while (popop() != "Nothing to pop") {
                if (popop() != "(")
                    ress += popop();

            }
            if (popop() != "Nothing to pop") {
                ress += popop();
            }
            return ress;
        }
        catch (Exception ex)
        {
            return "Something Failed";
        }
    }
    public String emptypopi()//POPPİNG ALL İNTEGERS AND RETURNS THEM
    {
        String resi;
        resi=popi();

        while(popi()!="Nothing to pop")
        {

            resi+=popi();
        }
        if(popi()!="Nothing to pop")
        {
            resi+=popi();
        }
        return resi;
    }
    public String popi()//POPİNG İNTEGERS
    {

        if(sayı.length()!=0)
        {
            String temp;
            temp=sayı.substring(0,sayı.length()-1);
            sayı=sayı.substring(0,sayı.length()-1);
            return temp;
        }
        else
        {
            return "Nothing to pop";
        }
    }
    public String calculate(String called)//POSTFİX CALCULATOR
    {

        return "";


    }
    public String postfix(String called)//POST FİX CONVERTER
    {
        boolean paran=false;
        int a;
        for(int i=0;i<called.length();i++) {
            try {
                if (called.substring(i, i) == "(")//PARANTEZ AÇILDI
                {
                    paran = true;
                    pushop("(");
                } else if (called.substring(i, i) == ")" && paran != true)//PARANTEZ HATASI
                {
                    String ress, resi;
                    resi = popi();
                    ress = popop();
                    while (ress != "Nothing to pop" && resi != "Nothing to pop") {
                        ress = popop();
                        resi = popi();
                    }
                    return "Parantez hatası";
                }
                else if (called.substring(i, i) == ")" && paran == true)//PARANTEZ KAPANDI
                {
                    String ress;
                    paran = false;
                    post+=emptypopi();
                    ress = emptypopop();
                }
                else if (ParseTry(called.substring(i, i)) == true)//SAYIYI STACKE ATIYOR
                {
                    int k = i;
                    String in = "";
                    while (ParseTry(called.substring(k, k)) == true)//SAYIYI OKUYOR
                    {
                        in += called.substring(k, k);
                        k++;
                    }
                    if (ParseTry(in) == true) //DOUBLE CHECK
                    {
                        k = Integer.parseInt(in);//SAYIYI ÇEVİRDİ
                        pushi(k);
                    } else//BEKLENMEYEN HATA
                    {
                        return "Unexpected Error";
                    }

                }
                else if (called.substring(i, i) == "+" || called.substring(i, i) == "-" || called.substring(i, i) == "x" || called.substring(i, i) == "/")//OPERATOR STACKE ATILIYOR
                {
                    if(called.substring(i, i) == "+" )
                    {
                        pushop(String.valueOf(1));
                    }
                    else if(called.substring(i, i) == "-" )
                    {
                        pushop(String.valueOf(2));
                    }
                    else if(called.substring(i, i) == "/" )
                    {
                        pushop(String.valueOf(3));
                    }
                    else if(called.substring(i, i) == "x" )
                    {
                        pushop(String.valueOf(4));
                    }

                }
                else
                {
                    return "Unexpected Character";
                }

            }
            catch(Exception ex)
            {
                return "Something Wrong with Class Function";
            }
        }

        return "";
    }

}
