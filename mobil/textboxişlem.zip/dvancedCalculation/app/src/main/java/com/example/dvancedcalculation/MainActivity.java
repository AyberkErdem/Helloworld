package com.example.dvancedcalculation;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.time.chrono.Era;

public class MainActivity extends AppCompatActivity {

    String ch;
   ImageButton AdBtn,MinBtn,MulBtn,DivBtn,CalcBtn,EraBtn;
Button sag,sol;
    EditText et;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         et=findViewById(R.id.TextScreen);
        AdBtn=(ImageButton)findViewById(R.id.AddBtn);
        MinBtn=(ImageButton)findViewById(R.id.MinusBtn);
        MulBtn=(ImageButton)findViewById(R.id.MultiBtn);
        DivBtn=(ImageButton)findViewById(R.id.DivideBtn);
        CalcBtn=(ImageButton)findViewById(R.id.CalculateBtn);
        EraBtn=(ImageButton)findViewById(R.id.BackBtn);
        sag=(Button)findViewById(R.id.SagParBtn);
        sol=(Button)findViewById(R.id.SolParBtn);
        sag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ch=et.getText().toString();
                ch+=")";
                et.setText(ch);
            }
        });
        sol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ch=et.getText().toString();
                ch+="(";
                et.setText(ch);
            }
        });
        AdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ch=et.getText().toString();
                ch+="+";
                et.setText(ch);
            }
        });
        MinBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ch=et.getText().toString();
                ch+="-";
                et.setText(ch);
            }
        });
        MulBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ch=et.getText().toString();
                ch+="x";
                et.setText(ch);
            }
        });
        DivBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ch=et.getText().toString();
                ch+="/";
                et.setText(ch);
            }
        });
        CalcBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result;
                int a;
                try {
                    yığın k=new yığın();
                    if(k.postfix(et.getText().toString())!="Parantez hatası"||k.postfix(et.getText().toString())!="Unexpected Error"
                            ||k.postfix(et.getText().toString())!="Unexpected Character")
                    {
                        try
                        {
                            result = yığor.infixToPostfix(et.getText().toString());
                            try
                            {
                                a = calc.evaluatePostfix(result);
                                try
                                {
                                    et.setText(String.valueOf(a));
                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                }
                                catch (Exception ex)
                                {
                                    Toast.makeText(getApplicationContext(), "Writing Error", Toast.LENGTH_SHORT).show();
                                }
                            }
                            catch (Exception ex)
                            {
                                Toast.makeText(getApplicationContext(), "Calculate Error", Toast.LENGTH_SHORT).show();
                            }
                        }
                        catch (Exception ex)
                        {
                            Toast.makeText(getApplicationContext(), "İnfix To Postfix Error", Toast.LENGTH_SHORT).show();
                        }



                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), k.postfix(et.getText().toString()), Toast.LENGTH_SHORT).show();
                    }

                }
                catch (Exception ex)
                {
                    Toast.makeText(getApplicationContext(),"Nope", Toast.LENGTH_SHORT).show();
                }
            }
        });
        EraBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ch=et.getText().toString();
                try
                {
                    ch=ch.substring(0,ch.length()-1);
                    et.setText(ch);
                }
                catch (Exception ex)
                {
                    Toast.makeText(getApplicationContext(),"Boş Silme Girişimi",Toast.LENGTH_SHORT).show();
                }

            }
        });
        et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
              if(hasFocus==true)
                v.setBackgroundColor(Color.GREEN);
              else
                  v.setBackgroundColor(Color.GRAY);
            }
        });

    }


    public void calculate(View view) {
    }
}
