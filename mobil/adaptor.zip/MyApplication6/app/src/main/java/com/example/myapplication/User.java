package com.example.myapplication;

public class User
{
    private String userName;
    private boolean userGender;
    private String age;


    public User(String userName,String age, boolean userGender) {
        this.userName = userName;
        this.userGender = userGender;
        this.age = age;

    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public boolean isUserGender() {
        return userGender;
    }

    public void setUserGender(boolean userGender) {
        this.userGender = userGender;
    }

    public String getage() {
        return age;
    }

    public void setCurrentTime(String currentTime) {
        this.age = currentTime;
    }


}
