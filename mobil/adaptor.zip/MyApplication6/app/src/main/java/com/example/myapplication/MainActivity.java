package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.LauncherActivity;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {
EditText t1,t2;
RadioButton rb1,rb2;
int select;
Button b1,b2,b3;
    final List<User> users = new ArrayList<User>();
     CustomAdapter adapter ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rb1=findViewById(R.id.ErkekBtn);
        rb2=findViewById(R.id.KadınBtn);
        SimpleDateFormat clockFormat = new SimpleDateFormat("hh:mm:ss");
        GregorianCalendar gcalender = new GregorianCalendar();
        String currentTime = clockFormat.format(gcalender.getTime());
        t1=findViewById(R.id.NameTxt);
        t2=findViewById(R.id.YasTxt);
        b2=findViewById(R.id.SilBtn);
        final ListView listView = (ListView) findViewById(R.id.listview);
        adapter = new CustomAdapter(this, users);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            User a=(User)adapter.getItem(position);
                t1.setText(a.getUserName());
                t2.setText(a.getage());
                select=position;
                if(a.isUserGender())
                {
                    rb2.setChecked(true);
                }
                else
                    {
                        rb1.setChecked(true);
                    }
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                users.remove(select);
                adapter.notifyDataSetChanged();
                }
                catch (Exception ex)
                {}
            }
        });

    }

    public void Ekle(View view)
    {
        if(t1.getText().length()==0)
        {

        }
        else if(t2.getText().length()==0)
        {

        }
        else if(rb1.isChecked()==false&&rb2.isChecked()==false)
        {

        }
        else if(rb1.isChecked()==true)
            {
                users.add(new User(t1.getText().toString(), t2.getText().toString(),false));
                SharedPreferences prefs = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor prefsEditor = prefs.edit();
                adapter.notifyDataSetChanged();
                prefsEditor.apply();

            }
        else if(rb2.isChecked()==true)
        {
            users.add(new User(t1.getText().toString(),t2.getText().toString(), true));
            SharedPreferences prefs = getPreferences(MODE_PRIVATE);
            SharedPreferences.Editor prefsEditor = prefs.edit();
            adapter.notifyDataSetChanged();
            prefsEditor.apply();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = prefs.edit();

        prefsEditor.apply();
    }

    public void selector(View view)
    {
        try{
             users.remove(select);
        if(rb1.isChecked()==true)
        {
            users.add(new User(t1.getText().toString(),t2.getText().toString(), false));
        }
        else if(rb2.isChecked()==true)
        {
            users.add(new User(t1.getText().toString(),t2.getText().toString(), true));
        }

        adapter.notifyDataSetChanged();
        }
        catch (Exception ex){}
    }
}
