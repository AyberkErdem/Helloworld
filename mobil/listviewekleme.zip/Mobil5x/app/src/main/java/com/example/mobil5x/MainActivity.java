package com.example.mobil5x;

import androidx.appcompat.app.AppCompatActivity;

import android.app.LauncherActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView L1;
    ArrayList categories;
    EditText et;
    String del;
    ArrayAdapter<String> dataAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        L1=(ListView)findViewById(R.id.liste1);
        categories=new ArrayList<String>();
        categories.add("aşure");
        categories.add("manti");
        categories.add("mercimek");
        categories.add("salata");
   dataAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, categories);
        L1.setAdapter(dataAdapter);
        et=(EditText)findViewById(R.id.editText);

    L1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        del=String.valueOf(position);
    }
    });
    }

    public void Yap(View view)
    {
        try {

            String c;
           // c = String.valueOf(et.getText());
            if (et.length()!=0)
            {
                String ek = String.valueOf(et.getText());
                et.setText("");
                categories.add(ek);
                dataAdapter.notifyDataSetChanged();
            }
            else
                {
                    Toast.makeText(this, "Boş isim", Toast.LENGTH_SHORT).show();
                }
        }
        catch (Exception ex)
        {

        }

    }
    boolean Tryparse(String s)
    {
        try
        {
            Integer.parseInt(s);
            return true;
        }
        catch (NumberFormatException ex)
        {
            return false;
        }

    }

    public void cık(View view)
    {
        try {
            String c;
            c = String.valueOf(et.getText());
            if (et.length()!=0 && Tryparse(del) == true) {
                String ek = String.valueOf(et.getText());
                et.setText("");
                int a = Integer.parseInt(del);
                categories.set(a, ek);
                dataAdapter.notifyDataSetChanged();
            }
            else
            {
                Toast.makeText(this, "Boş isim", Toast.LENGTH_SHORT).show();
            }

        }
        catch (Exception ex)
        {

        }
    }

    public void sil(View view)
    {
        try
        {
        if(Tryparse(del)==true)
        {
            String ek=String.valueOf(et.getText());
            et.setText("");
            int a=Integer.parseInt(del);
            categories.remove(a);
            dataAdapter.notifyDataSetChanged();
        }
        }
        catch (Exception ex)
        {

        }
    }
}

    /*
        L1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Toast.makeText(MainActivity.this, deger, Toast.LENGTH_SHORT).show();
            }
        });

         */