package com.example.myapplication2;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import java.util.Random;

import java.nio.charset.Charset;

public class MainActivity extends AppCompatActivity {
    EditText et,et1
            ;
    TextView tv;
    Button b1,b2,b3,b4;
    CharSequence str;
    Toast t;
    Random rn;
    float s1,s2,s3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.topbtn);
        b2=(Button)findViewById(R.id.eksibtn);
        b3=(Button)findViewById(R.id.bolbtn);
        b4=(Button)findViewById(R.id.multibtn);
        b4.setText("*");
        et=(EditText)findViewById(R.id.sayı1txt);
        et1=(EditText)findViewById(R.id.sayı2txt);
         tv=findViewById(R.id.sonuç);
         
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            s1= Float.parseFloat(et.getText().toString());
                s2= Float.parseFloat(et1.getText().toString());
                s3=s1+s2;
                tv.setText(String.valueOf(s3).toString());
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s1= Float.parseFloat(et.getText().toString());
                s2= Float.parseFloat(et1.getText().toString());
                s3=s1-s2;
                tv.setText(String.valueOf(s3).toString());
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                s1= Float.parseFloat(et.getText().toString());
                s2= Float.parseFloat(et1.getText().toString());
                if(s2!=0)
                {
                s3=s1/s2;
                tv.setText(String.valueOf(s3).toString());
                }
                else
                    {

                    }
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s1= Float.parseFloat(et.getText().toString());
                s2= Float.parseFloat(et1.getText().toString());
                s3=s1*s2;
                tv.setText(String.valueOf(s3).toString());
            }
        });
    }


}
